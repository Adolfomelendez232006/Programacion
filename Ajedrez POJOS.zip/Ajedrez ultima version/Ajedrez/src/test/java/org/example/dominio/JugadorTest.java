package org.example.dominio;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class JugadorTest {

    @org.junit.jupiter.api.Test
    void getiDJugador() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setiDJugador(2);

        assert jugador.getiDJugador()==2:"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setiDJugador() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setiDJugador(2);

        assert jugador.getiDJugador()==2:"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getNombre() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setNombre("A");

        assert jugador.getNombre().equals("A"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setNombre() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setNombre("N");

        assert jugador.getNombre().equals("N"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getApellido() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setApellido("A");

        assert jugador.getApellido().equals("A"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setApellido() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setApellido("A");

        assert jugador.getApellido().equals("A"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getConocimientoDeJuego() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setConocimientoDeJuego("M");

        assert jugador.getConocimientoDeJuego().equals("M"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setConocimientoDeJuego() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setConocimientoDeJuego("M");

        assert jugador.getConocimientoDeJuego().equals("M"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getFechaDeRegistro() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setFechaDeRegistro();

        assert jugador.getFechaDeRegistro() != null:"Fecha incorrecta";
    }

    @org.junit.jupiter.api.Test
    void setFechaDeRegistro() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now());
        jugador.setFechaDeRegistro();

        assert jugador.getFechaDeRegistro() != null:"Fecha incorrecta";
    }

}