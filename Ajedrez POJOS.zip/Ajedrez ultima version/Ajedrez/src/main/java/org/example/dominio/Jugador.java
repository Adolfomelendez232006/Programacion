package org.example.dominio;

import java.time.LocalDateTime;

public class Jugador {
    private String nombre;
    private String apellido;
    private int idJugador;
    private String conocimientoDeJuego;
    private LocalDateTime fechaDeRegistro;

    public Jugador(){
        this.idJugador = 12345;
        this.nombre = "Sin nombre";
        this.apellido = "Sin apellido";
        this.conocimientoDeJuego = "Sin nivel";
        this.fechaDeRegistro = LocalDateTime.now();

    }

    public Jugador(int id, String nombre,String apellido,String conocimiento, LocalDateTime fecha){
        this.idJugador = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.conocimientoDeJuego = conocimiento;
        this.fechaDeRegistro = fecha;

    }
    public int getidJugador(){
        return idJugador;
    }
    public void setidJugador(int idJugador){
        this.idJugador = idJugador;
    }

    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public String getApellido(){
        return apellido;
    }
    public void setApellido(String apellido){
        this.apellido = apellido;
    }

    public String getConocimientoDeJuego(){
        return conocimientoDeJuego;
    }
    public void setConocimientoDeJuego(String conocimientoDeJuego){
        this.conocimientoDeJuego = conocimientoDeJuego;
    }

    public LocalDateTime getFechaDeRegistro(){
        return fechaDeRegistro;
    }
    public void setFechaDeRegistro(){
        this.fechaDeRegistro = LocalDateTime.now();
    }
    //metodos
    public String toString(){
        return "Id: "+this.idJugador+" Nombre: "+this.nombre+" Apellido: "+this.apellido+" Conocimiento de juego "
                +this.conocimientoDeJuego+" Fecha de registro "+ fechaDeRegistro;
    }

}
