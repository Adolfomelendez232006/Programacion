package org.example.dominio;

import java.time.LocalDateTime;

public class Partida {
    private Jugador[] jugadores;
    private int numJugadores;

    public Partida(){
        jugadores = new Jugador[2];
        numJugadores = 0;

    }


    public Jugador getJugador(int indice){
        return jugadores[indice];
    }
    public void setJugador(int indice, Jugador jugador){
        jugadores[indice]=jugador;
    }

    public int getNumJugadores() {
        return numJugadores;
    }


    public void registrarJugador(int id, String nombre,String apellido,String conocimiento, LocalDateTime fecha){
        jugadores[numJugadores] = new Jugador(id,nombre,apellido,conocimiento,fecha);
        numJugadores++;

    }

    public void editarJugador(int indice,int id, String nombre,String apellido,String conocimiento, LocalDateTime fecha){
        jugadores[indice] = new Jugador(id,nombre,apellido,conocimiento,fecha);
    }

    public String buscarJugador(){
        String tex = "";

        for (Jugador jugador : jugadores) {
            tex += jugador+"\r\n";
            //System.out.println(cliente);
        }
        return tex;
    }

    public void borrarJugador(int indice){
        for (int i = indice; i < numJugadores - 1; i++) {
            jugadores[i] = jugadores[i + 1];
        }
        jugadores[numJugadores - 1] = null;
        numJugadores--;
    }
}
