package org.example.dominio;

public class Recompensa {
    private String tipo;
    private int puntos;

    public Recompensa(String tipo, int puntos) {
        this.tipo = tipo;
        this.puntos = puntos;
    }

    public int getPuntos() {
        return puntos;
    }
    public String getTipo(){
        return tipo;
    }

    public void setPuntos(int puntos){
        this.puntos = puntos;
    }
    public void setTipo(String tipo){
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Recompensa tipo= " + tipo + ", puntos= " + puntos;
    }
}
