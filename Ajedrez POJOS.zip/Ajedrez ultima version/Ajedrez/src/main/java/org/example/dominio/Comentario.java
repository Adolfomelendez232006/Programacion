package org.example.dominio;

import java.time.LocalDateTime;

public class Comentario {
    private String autor;
    private String contenido;
    //private int calificacion;
    private LocalDateTime fecha;

    public Comentario(String autor,String contenido){
        this.autor = autor;
        this.contenido = contenido;
        this.fecha = LocalDateTime.now();

    }

    public String getAutor(){
        return autor;
    }
    public void setAutor(){
        this.autor = autor;
    }
    public String getContenido(){
        return contenido;
    }
    public void setContenido(){
        this.contenido = contenido;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "Comentario autor= " + autor + ", contenido= " + contenido+ ", fecha=" + fecha;
    }
}
