package org.example.dominio;

import java.util.ArrayList;
import java.util.List;

public class GestorRecompensas {
    private List<Recompensa> recompensas;

    public GestorRecompensas() {
        this.recompensas = new ArrayList<>();
    }

    public void registrarRecompensas(String tipo,int puntos){
        Recompensa recompensa = new Recompensa(tipo, puntos);
        recompensas.add(recompensa);
        System.out.println("Recompensa anadida");

    }

    public void listaDeRecompensas() {
        System.out.println("Historial de recompensas:");
        for (Recompensa recompensa : recompensas) {
            System.out.println(recompensa);
        }
    }

    public int calcularTotalPuntos() {
        int total = 0;
        for (Recompensa recompensa : recompensas) {
            total += recompensa.getPuntos();
        }
        return total;
    }

}
