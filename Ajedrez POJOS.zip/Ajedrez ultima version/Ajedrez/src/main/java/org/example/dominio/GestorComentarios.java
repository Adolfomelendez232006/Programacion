package org.example.dominio;

import java.util.ArrayList;
import java.util.List;

public class GestorComentarios {
    private List<Comentario> comentarios;

    //Metodo constructor
    public GestorComentarios(){
        comentarios = new ArrayList<>();
    }

    public void registrarComentario(String usuario, String texto){
        Comentario comentario = new Comentario(usuario,texto);
        comentarios.add(comentario);
        System.out.println("Comentario registrado con exito");
    }

    public void listarComentarios(){
        System.out.println("Lista de comentarios:");
        for (Comentario comentario : comentarios) {
            System.out.println(comentario);
        }
    }

    public void eliminarComentario(int indice){
        comentarios.remove(indice);
        System.out.println("Comentario eliminado");
    }
}
