package dominio;

import org.example.dominio.Recompensa;
import org.example.dominio.SolicitudDeRecompensa;

public class TestSolicitudDeReconpensa {
    public static void main(String[] args) {

        // Crear una recompensa
        Recompensa recompensa1 = new Recompensa("Ganador","Partida ganada 100 puntos", 100);

        // Crear solicitud
        SolicitudDeRecompensa solicitud = new SolicitudDeRecompensa();

        boolean creada = solicitud.crearSolicitud(recompensa1);
        System.out.println("Solicitud creada: " + creada + "\n");

        System.out.println(solicitud.estadoDeSolicitud() + "\n");

        boolean aprobada = solicitud.aprobarSolicitud();
        System.out.println("Solicitud aprobada: " + aprobada + "\n");

        System.out.println("¿Está aprobada? " + solicitud.estaAprobada());
        System.out.println(solicitud.estadoDeSolicitud() + "\n");

        boolean procesada = solicitud.procesarSolicitud();
        System.out.println("Solicitud procesada: " + procesada + "\n");

        SolicitudDeRecompensa solicitud2 = new SolicitudDeRecompensa();
        Recompensa recompensa2 = new Recompensa("Empate ", "Partida empatada 50 puntos",  50);

        solicitud2.crearSolicitud(recompensa2);
        boolean rechazada = solicitud2.rechazarSolicitud("Puntos insuficientes del usuario");
        System.out.println("Solicitud rechazada: " + rechazada);
        System.out.println("¿Está rechazada? " + solicitud2.estaRechazada());
        System.out.println(solicitud2.estadoDeSolicitud());
    }
}
