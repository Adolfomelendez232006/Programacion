package org.example.Datos;

import org.example.dominio.Genero;
import org.example.dominio.Jugador;
import org.example.dominio.Partida;
import org.example.dominio.Recompensa;

import java.time.LocalDateTime;
import java.util.Date;

public interface CompetenciaDAO {
    // Métodos CRUD para Jugadores
    void registrarJugador(int id, String nombre, String apellido, String conocimiento,
                          LocalDateTime fecha, Genero genero);
    void registrarJugador(Jugador jugador);
    Jugador buscarJugador(int id);
    int buscarIndicePorId(int id);
    void modificarJugador(int indice, int id, String nombre, String apellido,
                          String conocimiento, LocalDateTime fecha, Genero genero);
    void modificarJugador(int indice, Jugador jugador);
    boolean borrarJugador(int id);

    // Métodos CRUD para Recompensas
    void agregarRecompensa(Recompensa recompensa);
    Recompensa buscarRecompensa(Recompensa recompensa);
    Recompensa obtenerRecompensa(int indice);
    void editarRecompensa(int indice, Recompensa nuevaRecompensa);
    boolean borrarRecompensa(int indice);

    // Métodos CRUD para Partidas
    void agregarPartida(Partida partida);
    Partida obtenerPartida(int indice);
    void editarPartida(int indice, Partida nuevaPartida);
    boolean borrarPartida(int indice);

    // Métodos de validación
    boolean validarDuplicado(Object obj);

    // Métodos de control de competencia
    void iniciarCompetencia();
    void setIniciarCompetencia();
    void finalizarCompetencia();

    // Métodos de gestión de instancia (Singleton)
    static CompetenciaDAO getInstancia() {
        throw new UnsupportedOperationException("Debe implementarse en la clase concreta");
    }

    static CompetenciaDAO getInstancia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        throw new UnsupportedOperationException("Debe implementarse en la clase concreta");
    }

    static void reiniciarInstancia() {
        throw new UnsupportedOperationException("Debe implementarse en la clase concreta");
    }

    static void reiniciarContador() {
        throw new UnsupportedOperationException("Debe implementarse en la clase concreta");
    }

    static int getTotalCompetenciasCreadas() {
        throw new UnsupportedOperationException("Debe implementarse en la clase concreta");
    }
}
