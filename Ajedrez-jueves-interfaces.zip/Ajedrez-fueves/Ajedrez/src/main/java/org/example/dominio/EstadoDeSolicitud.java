package org.example.dominio;

public enum EstadoDeSolicitud {
    PENDIENTE("PENDIENTE", "La solicitud está pendiente de revisión"),
    APROBADA("APROBADA", "La solicitud ha sido aprobada"),
    RECHAZADA("RECHAZADA", "La solicitud ha sido rechazada"),
    PROCESADA("PROCESADA", "La solicitud ha sido procesada y la recompensa entregada");

    private String nombre;
    private String descripcion;

    // Constructor del enum
    private EstadoDeSolicitud(String nombre,String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }
    public String getDescripcion() {
        return descripcion;
    }
    // Metodo para obtener enum desde String
    public static EstadoDeSolicitud fromCodigo(String codigo) {
        for (EstadoDeSolicitud estado : EstadoDeSolicitud.values()) {
            if (estado.getNombre().equalsIgnoreCase(codigo)) {
                return estado;
            }
        }
        return PENDIENTE; // Estado por defecto
    }

    @Override
    public String toString() {
        return nombre + " - " + descripcion;
    }
}
