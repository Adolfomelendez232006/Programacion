package org.example.dominio;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

/**
 * Esta clase representa una competencia o torneo.
 * Aquí se guarda la información del torneo, como su nombre, las fechas,
 * los participantes y los enfrentamientos que se generan.
 */
public class Competencia {
        private String nombreTorneo;
        private Date fechaInicio;
        private Date fechaFin;
        private boolean iniciada;
        private boolean finalizada;
        private EstadoCompetencia estado;
        public static final int CAPACIDAD_INICIAL_JUGADORES = 3;
        public static final int CAPACIDAD_INICIAL_RECOMPENSAS = 3;
        public static final int CAPACIDAD_INICIAL_PARTIDAS = 3;
        public static final int FACTOR_EXPANSION = 2;
        // Contador estático para llevar el control de competencias creadas
        private static int contadorCompetencias = 0;
        // Instancia única para el patrón Singleton
        private static Competencia instancia;
        // ID único de la competencia (final, se asigna una sola vez)
        private final int idCompetencia;
        // Arreglos para manejar las entidades relacionadas
        public Jugador[] jugadores;
        private Recompensa[] recompensas;
        private Partida[] partidas;

        // Contadores para llevar el control de elementos actuales
        private int numJugadores = 0;
        private int numEnfrentamientos;
        private int numRecompensas;
        private int numPartidas;

    public Competencia(){
        this("Sin nombre de Torneo",new Date(),new Date());
    }
        /**
         * Constructor para crear una competencia.
         * Verifica que el nombre y las fechas sean válidas antes de guardar.
         *
         * @param nombreTorneo nombre del torneo.
         * @param fechaInicio  cuándo empieza el torneo.
         * @param fechaFin     cuándo termina el torneo.
         */
    public Competencia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        // Validaciones del nombre
        if (nombreTorneo == null || nombreTorneo.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (!nombreTorneo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras");
        }
        if (nombreTorneo.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres");
        }

        // Validaciones de fechas
        if (fechaInicio == null || fechaFin == null) {
            throw new IllegalArgumentException("Las fechas no pueden ser nulas.");
        }
        if (fechaFin.before(fechaInicio)) {
            throw new IllegalArgumentException("La fecha de fin no puede ser anterior a la de inicio.");
        }
        this.idCompetencia=++contadorCompetencias;
        this.nombreTorneo = nombreTorneo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.iniciada = false;
        this.finalizada = false;
        this.estado = EstadoCompetencia.NO_INICIADA;

        inicializarArreglos();
    }
        // Métodos Singleton
        public static Competencia getInstancia() {
        if (instancia == null) {
            instancia = new Competencia();
        }
        return instancia;
    }
        public static Competencia getInstancia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        if (instancia == null) {
            instancia = new Competencia(nombreTorneo, fechaInicio, fechaFin);
        }
        return instancia;
    }

        // Método para reiniciar la instancia
        public static void reiniciarInstancia() {
        instancia = null;
    }

        public static void reiniciarContador() {
        contadorCompetencias = 0;
    }
        private void inicializarArreglos() {
        this.jugadores = new Jugador[CAPACIDAD_INICIAL_JUGADORES];
        this.recompensas = new Recompensa[CAPACIDAD_INICIAL_RECOMPENSAS];
        this.partidas = new Partida[CAPACIDAD_INICIAL_PARTIDAS];
        this.numJugadores = 0;
        this.numEnfrentamientos = 0;
        this.numRecompensas = 0;
        this.numPartidas = 0;
    }
        /**
         * Agrega un nuevo participante a la competencia si no ha sido agregado antes.
         *
         * @param nombre Nombre del jugador a agregar.
         */
        public void registrarJugador(int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (buscarJugador(id) != null) {
            throw new IllegalArgumentException("Ya existe un jugador con este id.");
        }

        if (numJugadores >= jugadores.length) {
            Jugador[] nuevoArreglo = new Jugador[jugadores.length * 2];
            System.arraycopy(jugadores, 0, nuevoArreglo, 0, jugadores.length);
            jugadores = nuevoArreglo;
        }

        jugadores[numJugadores] = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
        numJugadores++;
    }

        public void registrarJugador(Jugador jugador) {
        if (jugador == null || buscarJugador(jugador.getIdJugador()) != null) return;

        if (numJugadores >= jugadores.length) {
            Jugador[] nuevoArreglo = new Jugador[jugadores.length * 2];
            System.arraycopy(jugadores, 0, nuevoArreglo, 0, jugadores.length);
            jugadores = nuevoArreglo;
        }

        jugadores[numJugadores] = jugador;
        numJugadores++;
    }

        /**
         * Busca un jugador por su ID
         * @param id identifica el jugador a buscar
         * @return El jugador encontrado, o null si no existe
         */

        public Jugador buscarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                return jugadores[i];
            }
        }
        return null;
    }

        /**
         * Busca el índice de un jugador por su ID
         */
        public int buscarIndicePorId(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                return i;
            }
        }
        return -1;
    }

        /**
         * Editar los datos de un jugador existente en la posicion especifica
         * @param indice posicion del jugador a editar
         * @param id nuevo Id del jugador
         * @param nombre nuevo nombre del jugador
         * @param apellido nuevo apellido del jugador
         * @param conocimiento nuevo nivel de conocimiento
         * @param fecha nueva fecha de registro
         */
        public void modificarJugador(int indice, int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        jugadores[indice] = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
    }

        public void modificarJugador(int indice, Jugador jugador) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }

        boolean idCambiado = jugadores[indice].getIdJugador() != jugador.getIdJugador();
        boolean idYaExiste = buscarJugador(jugador.getIdJugador()) != null;

        if (idCambiado && idYaExiste) {
            throw new IllegalArgumentException("Ya existe otro jugador con ese ID.");
        }

        jugadores[indice] = jugador;
    }
        /**
         * Elimina un jugador de la parida por su Id
         * @param id identificador del jugador a eliminar
         * @return true si el jugador fue eliminado o false si no es encontrado
         */
        public boolean borrarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numJugadores - 1; j++) {
                    jugadores[j] = jugadores[j + 1];
                }
                jugadores[numJugadores - 1] = null;
                numJugadores--;
                return true;
            }
        }
        return false;
    }
        /**
         * Expande el arreglo de recompensas
         */
        private void expandirArregloRecompensas() {
        Recompensa[] nuevoArreglo = new Recompensa[recompensas.length * 2];
        System.arraycopy(recompensas, 0, nuevoArreglo, 0, recompensas.length);
        recompensas = nuevoArreglo;
    }

        public void agregarRecompensa(Recompensa recompensa) {
        if (numRecompensas >= recompensas.length) {
            expandirArregloRecompensas();
        }
        recompensas[numRecompensas] = recompensa;
        numRecompensas++;
    }


        public Recompensa buscarRecompensa(Recompensa recompensa) {
        for (int i = 0; i < numRecompensas; i++) {
            if (recompensas[i].equals(recompensa)) {
                return recompensas[i];
            }
        }
        return null;
    }
        /**
         * Busca una recompensa por índice
         */
        public Recompensa obtenerRecompensa(int indice) {
        if (indice >= 0 && indice < numRecompensas) {
            return recompensas[indice];
        }
        return null;
    }

        /**
         * Edita una recompensa en un índice específico
         */
        public void editarRecompensa(int indice, Recompensa nuevaRecompensa) {
        if (indice < 0 || indice >= numRecompensas) {
            throw new IndexOutOfBoundsException("Índice de recompensa no válido.");
        }

        if (nuevaRecompensa == null) {
            throw new IllegalArgumentException("La recompensa no puede ser nula.");
        }

        for (int i = 0; i < numRecompensas; i++) {
            if (i != indice && recompensas[i].equals(nuevaRecompensa)) {
                throw new IllegalArgumentException("Ya existe una recompensa igual.");
            }
        }

        recompensas[indice] = nuevaRecompensa;
    }
        /**
         * Elimina una recompensa por índice
         */
        public boolean borrarRecompensa(int indice) {
        if (indice < 0 || indice >= numRecompensas) {
            return false;
        }

        for (int i = indice; i < numRecompensas - 1; i++) {
            recompensas[i] = recompensas[i + 1];
        }

        recompensas[numRecompensas - 1] = null;
        numRecompensas--;
        return true;
    }
        /**
         * Expande el arreglo de partidas
         */
        private void expandirArregloPartidas() {
        Partida[] nuevoArreglo = new Partida[partidas.length * 2];
        System.arraycopy(partidas, 0, nuevoArreglo, 0, partidas.length);
        partidas = nuevoArreglo;
    }
        /**
         * Agrega una partida a la competencia
         */
        public void agregarPartida(Partida partida) {
        if (numPartidas >= partidas.length) {
            expandirArregloPartidas();
        }
        partidas[numPartidas] = partida;
        numPartidas++;
    }

        public Partida obtenerPartida(int indice) {
        if (indice >= 0 && indice < numPartidas) {
            return partidas[indice];
        }
        return null;
    }

        public void editarPartida(int indice, Partida nuevaPartida) {
        if (indice < 0 || indice >= numPartidas) {
            throw new IndexOutOfBoundsException("Índice de partida no válido.");
        }

        if (nuevaPartida == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }

        for (int i = 0; i < numPartidas; i++) {
            if (i != indice && partidas[i].equals(nuevaPartida)) {
                throw new IllegalArgumentException("Ya existe una partida igual.");
            }
        }

        partidas[indice] = nuevaPartida;
    }

        public boolean borrarPartida(int indice) {
        if (indice < 0 || indice >= numPartidas) {
            return false;
        }

        for (int i = indice; i < numPartidas - 1; i++) {
            partidas[i] = partidas[i + 1];
        }

        partidas[numPartidas - 1] = null;
        numPartidas--;
        return true;
    }
        public boolean validarDuplicado(Object obj) {
        if (obj == null) return false;

        // Validar duplicado de Jugador
        if (obj instanceof Jugador) {
            Jugador jugador = (Jugador) obj;
            for (int i = 0; i < numJugadores; i++) {
                if (jugadores[i] != null && jugadores[i].equals(jugador)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Recompensa
        else if (obj instanceof Recompensa) {
            Recompensa recompensa = (Recompensa) obj;
            for (int i = 0; i < numRecompensas; i++) {
                if (recompensas[i] != null && recompensas[i].equals(recompensa)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Partida
        else if (obj instanceof Partida) {
            Partida partida = (Partida) obj;
            for (int i = 0; i < numPartidas; i++) {
                if (partidas[i] != null && partidas[i].equals(partida)) {
                    return true;
                }
            }
        }

        return false; // Si no es ninguno de los anteriores o no hay duplicado
    }

        /**
         * Método estático para obtener el número total de competencias creadas
         */
        public static int getTotalCompetenciasCreadas() {
        return contadorCompetencias;
    }
        /**
         * Inicia la competencia si aún no ha comenzado.
         * Muestra un mensaje diciendo si se pudo iniciar o si ya estaba iniciada.
         */
        public void iniciarCompetencia() {
        if (!iniciada) {
            this.iniciada = true;
            System.out.println("Competencia iniciada.");
        } else {
            System.out.println("La competencia ya estaba iniciada.");
        }
    }
        /**
         * Marca la competencia como iniciada directamente.
         */

        public void setIniciarCompetencia() {
        this.iniciada = true;
    }

        /**
         * Marca la competencia como finalizada y muestra un mensaje.
         */

        public void finalizarCompetencia() {
        this.finalizada = true;
        System.out.println("Competencia finalizada.");
    }

        // Métodos getter y setter
        public String getNombreTorneo() {
        return nombreTorneo;
    }

        public void setNombreTorneo(String nombreTorneo) {
        this.nombreTorneo = nombreTorneo;
    }

        public Date getFechaInicio() {
        return fechaInicio;
    }

        public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

        public Date getFechaFin() {
        return fechaFin;
    }

        public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

        public boolean isIniciada() {
        return iniciada;
    }

        public boolean isFinalizada() {
        return finalizada;
    }

        public int getNumJugadores() {
        return numJugadores;
    }

        public int getNumEnfrentamientos() {
        return numEnfrentamientos;
    }

        public int getNumRecompensas() {
        return numRecompensas;
    }

        public int getNumPartidas() {
        return numPartidas;
    }

        public Jugador getJugadores(int indice) {
        if (indice >= 0 && indice < numJugadores) {
            return jugadores[indice];
        } else {
            return null;
        }
    }

    /*public Enfrentamiento[] getEnfrentamientos() {
        return enfrentamientos;
    }*/

        public Recompensa[] getRecompensas() {
        return recompensas;
    }

        public Partida[] getPartidas() {
        return partidas;
    }

        /**
         * Representación en cadena de la competencia con toda su información
         */
        @Override
        public String toString() {
        StringBuilder sb = new StringBuilder();

        // Información básica de la competencia
        sb.append("=== COMPETENCIA ===\n");
        sb.append("Nombre del Torneo: ").append(nombreTorneo).append("\n");
        sb.append("Fecha de Inicio: ").append(fechaInicio).append("\n");
        sb.append("Fecha de Fin: ").append(fechaFin).append("\n");
        sb.append("Estado: ").append(estado.getDescripcion()).append("\n\n");

        // Información de jugadores
        sb.append("=== JUGADORES REGISTRADOS (").append(numJugadores).append(") ===\n");
        if (numJugadores == 0) {
            sb.append("No hay jugadores registrados.\n");
        } else {
            for (int i = 0; i < numJugadores; i++) {
                sb.append((i + 1)).append(". ").append(jugadores[i].toString()).append("\n");
            }
        }
        sb.append("\n");
        // Información de recompensas
        sb.append("=== RECOMPENSAS (").append(numRecompensas).append(") ===\n");
        if (numRecompensas == 0) {
            sb.append("No hay recompensas definidas.\n");
        } else {
            for (int i = 0; i < numRecompensas; i++) {
                sb.append((i + 1)).append(". ").append(recompensas[i].toString()).append("\n");
            }
        }
        sb.append("\n");

        // Información de partidas
        sb.append("=== PARTIDAS (").append(numPartidas).append(") ===\n");
        if (numPartidas == 0) {
            sb.append("No hay partidas registradas.\n");
        } else {
            for (int i = 0; i < numPartidas; i++) {
                sb.append((i + 1)).append(". ").append(partidas[i].toString()).append("\n");
            }
        }
        return sb.toString();
    }
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Competencia)) {
            return false;
        }
        Competencia otraCompetencia = (Competencia) obj;
        return
                this.idCompetencia == otraCompetencia.idCompetencia &&
                        Objects.equals(this.nombreTorneo, otraCompetencia.nombreTorneo) &&
                        Objects.equals(this.fechaInicio, otraCompetencia.fechaInicio) &&
                        Objects.equals(this.fechaFin, otraCompetencia.fechaFin);
    }
    @Override
    public int hashCode() {
        return Objects.hash(nombreTorneo, fechaInicio, fechaFin);
    }
}


