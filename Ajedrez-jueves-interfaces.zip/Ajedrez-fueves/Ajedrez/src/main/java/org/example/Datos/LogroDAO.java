package org.example.Datos;

import org.example.dominio.Logro;

public interface LogroDAO {
    String registrarLogro(Logro logro);

    String registrarLogro(String nombre, String descripcion, int puntos, boolean completado);

    String listarLogros();

    String listarLogros(boolean completado);

    String listarLogros(String nombre);

    String eliminarLogro(int indice);

    String eliminarLogro(String nombre);

    String editarLogro(int indice, String nuevoNombre, String nuevaDescripcion, int nuevosPuntos);

    String completarLogro(int indice);

    String completarLogro(String nombre);

    String reiniciarLogro(int indice);

    String reiniciarLogro(String nombre);

    int getCantidadLogros();

    int getCantidadLogrosCompletados();

    int getCantidadLogrosPendientes();
}
