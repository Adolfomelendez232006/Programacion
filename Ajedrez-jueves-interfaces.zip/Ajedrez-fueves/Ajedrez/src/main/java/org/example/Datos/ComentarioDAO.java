package org.example.Datos;

import org.example.dominio.Comentario;

public interface ComentarioDAO {
    String registrarComentario(String usuario, String texto);
    String registrarComentario(Comentario nuevoComentario);
    String listarComentarios();
    String listarComentarios(String autorBuscado);

    String eliminarComentario(int indice);

    String eliminarComentario(String autor);
    String editarComentario(int indice, String nuevoContenido);

    String editarComentario(int indice, String nuevoAutor, String nuevoContenido);

    int getCantidadComentarios();
}
