package org.example.Datos;

import org.example.dominio.Logro;

public class LogroDAOMemoryImpl implements LogroDAO{
    private static final int TAMAÑO_INICIAL = 5;
    private Logro[] logros;
    private int cantidadLogros;


    @Override
    public String registrarLogro(Logro logro) {
        if (logro == null) {
            return "Error: El logro no puede ser nulo.";
        }

        // Verificar si necesitamos expandir el arreglo
        if (this.cantidadLogros >= this.logros.length) {
            Logro[] nuevoArreglo = new Logro[this.logros.length * 2];
            System.arraycopy(this.logros, 0, nuevoArreglo, 0, this.logros.length);
            this.logros = nuevoArreglo;

        }

        this.logros[this.cantidadLogros] = logro;
        this.cantidadLogros++;
        return "Logro registrado con éxito.";
    }

    @Override
    public String registrarLogro(String nombre, String descripcion, int puntos, boolean completado) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre del logro no puede estar vacío.";
        }

        Logro nuevoLogro = new Logro(nombre, descripcion, puntos, completado);
        return registrarLogro(nuevoLogro);
    }

    @Override
    public String listarLogros() {
        if (this.cantidadLogros == 0) {
            return "No hay logros registrados.";
        }

        String resultado = "Lista de logros:\n";
        for (int i = 0; i < this.cantidadLogros; i++) {
            resultado += "[" + i + "] " + this.logros[i].toString() + "\n\n";
        }
        return resultado;
    }

    @Override
    public String listarLogros(boolean completado) {
        String estado = completado ? "completados" : "pendientes";
        String resultado = "Logros " + estado + ":\n";
        boolean encontrado = false;

        for (int i = 0; i < this.cantidadLogros; i++) {
            if (this.logros[i].isCompletado() == completado) {
                resultado += "[" + i + "] " + this.logros[i].toString() + "\n\n";
                encontrado = true;
            }
        }

        if (!encontrado) {
            resultado += "No se encontraron logros " + estado + ".\n";
        }
        return resultado;
    }

    @Override
    public String listarLogros(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre a buscar no puede estar vacío.";
        }

        String resultado = "Logros que contienen '" + nombre + "':\n";
        boolean encontrado = false;

        for (int i = 0; i < this.cantidadLogros; i++) {
            String nombreLogro = this.logros[i].getNombre();
            if (nombreLogro != null && nombreLogro.toLowerCase().contains(nombre.toLowerCase())) {
                resultado += "[" + i + "] " + this.logros[i].toString() + "\n\n";
                encontrado = true;
            }
        }

        if (!encontrado) {
            resultado += "No se encontraron logros con ese nombre.\n";
        }
        return resultado;
    }

    @Override
    public String eliminarLogro(int indice) {
        if (indice < 0 || indice >= this.cantidadLogros) {
            return "Índice inválido.";
        }

        // Desplazar elementos hacia la izquierda
        for (int i = indice; i < this.cantidadLogros - 1; i++) {
            this.logros[i] = this.logros[i + 1];
        }

        // Limpiar la última posición
        this.logros[this.cantidadLogros - 1] = null;
        this.cantidadLogros--;

        return "Logro eliminado con éxito.";
    }

    @Override
    public String eliminarLogro(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre no puede estar vacío.";
        }

        for (int i = 0; i < this.cantidadLogros; i++) {
            String nombreLogro = this.logros[i].getNombre();
            if (nombreLogro != null && nombreLogro.equalsIgnoreCase(nombre)) {
                return eliminarLogro(i);
            }
        }
        return "No se encontró logro con ese nombre.";
    }

    @Override
    public String editarLogro(int indice, String nuevoNombre, String nuevaDescripcion, int nuevosPuntos) {
        if (indice < 0 || indice >= this.cantidadLogros) {
            return "Índice inválido.";
        }

        if (nuevoNombre == null || nuevoNombre.trim().isEmpty()) {
            return "Error: El nombre no puede estar vacío.";
        }

        this.logros[indice].setNombre(nuevoNombre);
        this.logros[indice].setDescripcion(nuevaDescripcion);
        this.logros[indice].setPuntos(nuevosPuntos);

        return "Logro editado con éxito.";
    }

    @Override
    public String completarLogro(int indice) {
        if (indice < 0 || indice >= this.cantidadLogros) {
            return "Índice inválido.";
        }

        if (this.logros[indice].isCompletado()) {
            return "El logro ya está completado.";
        }

        this.logros[indice].setCompletado(true);
        return "Logro '" + this.logros[indice].getNombre() + "' completado con éxito.";
    }

    @Override
    public String completarLogro(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre no puede estar vacío.";
        }

        for (int i = 0; i < this.cantidadLogros; i++) {
            String nombreLogro = this.logros[i].getNombre();
            if (nombreLogro != null && nombreLogro.equalsIgnoreCase(nombre)) {
                return completarLogro(i);
            }
        }
        return "No se encontró logro con ese nombre.";
    }

    @Override
    public String reiniciarLogro(int indice) {
        if (indice < 0 || indice >= this.cantidadLogros) {
            return "Índice inválido.";
        }

        if (!this.logros[indice].isCompletado()) {
            return "El logro ya está pendiente.";
        }

        this.logros[indice].reiniciarLogro();
        return "Logro '" + this.logros[indice].getNombre() + "' reiniciado con éxito.";
    }

    @Override
    public String reiniciarLogro(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre no puede estar vacío.";
        }

        for (int i = 0; i < this.cantidadLogros; i++) {
            String nombreLogro = this.logros[i].getNombre();
            if (nombreLogro != null && nombreLogro.equalsIgnoreCase(nombre)) {
                return reiniciarLogro(i);
            }
        }
        return "No se encontró logro con ese nombre.";
    }

    @Override
    public int getCantidadLogros() {
        return this.cantidadLogros;
    }

    @Override
    public int getCantidadLogrosCompletados() {
        int contador = 0;
        for (int i = 0; i < this.cantidadLogros; i++) {
            if (this.logros[i].isCompletado()) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public int getCantidadLogrosPendientes() {
        int contador = 0;
        for (int i = 0; i < this.cantidadLogros; i++) {
            if (!this.logros[i].isCompletado()) {
                contador++;
            }
        }
        return contador;
    }

    public Logro obtenerLogro(int indice) {
        if (indice >= 0 && indice < this.cantidadLogros) {
            return this.logros[indice];
        }
        return null;
    }

    public boolean estaVacio() {
        return this.cantidadLogros == 0;
    }

    public double getPorcentajeCompletado() {
        if (this.cantidadLogros == 0) {
            return 0.0;
        }
        return (double) getCantidadLogrosCompletados() / this.cantidadLogros;
    }

    public int getTotalPuntosCompletados() {
        int total = 0;
        for (int i = 0; i < this.cantidadLogros; i++) {
            if (this.logros[i].isCompletado()) {
                total += this.logros[i].getPuntos();
            }
        }
        return total;
    }
}
