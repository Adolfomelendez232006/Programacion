package org.example.Datos;

import org.example.dominio.Contrincante;
import org.example.dominio.EstadoEnfrentamiento;
import org.example.dominio.Jugador;
import org.example.dominio.Partida;

import java.time.LocalDateTime;

public interface PartidaDAO {
    // Métodos de creación
    String crearPartidaMaquina();
    String crearPartidaMaquina(String soPartida);
    String crearPartidaMultijugador();
    String crearPartidaMultijugador(String soPartida);

    // Métodos de registro
    String registrarPartida(int punJ1, int punJ2, String obs,
                            LocalDateTime fecha, Contrincante con, EstadoEnfrentamiento estado, String contrincante);
    String registrarPartida(Partida partida);

    // Métodos de consulta
    String consultarPartida();
    String consultarPartida(Partida partida);

    // Métodos de búsqueda
    int buscarPartidaPorId(int id);
    int buscarPartidaPorId(int id, Partida partida);

    // Métodos de edición
    void editarPartida(int indice, int puntajeJugador1, int puntajeJugador2,
                       String observaciones, Contrincante con, LocalDateTime fecha);

    // Métodos de eliminación
    boolean eliminarPartida(int id);
    boolean eliminarPartida(int id, Partida partida);

    // Métodos de asignación de resultados
    String asignarEmpate();
    String asignarResultadoConPuntaje(int puntajeJ1, int puntajeJ2);
    String asignarGanador(Jugador nombreGanador);
    String asignarResultados(String resultado);

    // Métodos de validación
    boolean validarDuplicadoJugador();
}
