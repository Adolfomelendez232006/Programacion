package org.example.dominio;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Objects;

/**
 * Representa un jugador en el sistema, almacenando su informacion personal,
 * nivel de conocimiento, fecha de registro y recompensas obtenidas
 *
 * <p>la clase incliye con validaciones para garantixar la integridad de los
 * datos del jugador al momento de su creacion.</p>
 * @autores Adolfo Melendes- Daniel Riofrio - Karol Gomez- Dana Palacios
 */
public class Jugador {
    public String nombre;
    private String apellido;
    private int idJugador;
    private String conocimientoDeJuego;
    private LocalDateTime fechaDeRegistro;
    private SolicitudDeRecompensa[] recompensas;
    private Comentario[] comentarios;
    private Recompensa[] recompensasObtenidas;
    private Logro[] logros;
    private int puntosAcumulados;
    private Genero genero;
    private int contadorComentarios;
    private int contadorRecompensas;
    private int contadorRecompensasObtenidas;
    private int contadorLogros;
    private static final int MAX_COMENTARIOS = 100;
    private static final int MAX_RECOMPENSAS = 50;
    private static final int MAX_RECOMPENSAS_OBTENIDAS = 100;
    private static final int MAX_LOGROS = 50;
    /**
     * Constructor por defecto que inicializa un jugador con valores por defecto
     */
    public Jugador(int i, String s, String string, String s1, LocalDateTime now) {
        this.idJugador = getIdJugador();
        this.nombre = getNombre();
        this.apellido = getApellido();
        this.conocimientoDeJuego = getConocimientoDeJuego();
        this.fechaDeRegistro = getFechaDeRegistro();
        this.recompensas = new SolicitudDeRecompensa[MAX_RECOMPENSAS];
        this.comentarios = new Comentario[MAX_COMENTARIOS];
        this.recompensasObtenidas=new Recompensa[MAX_RECOMPENSAS_OBTENIDAS];
        this.logros=new Logro[MAX_LOGROS];
        this.fechaDeRegistro = LocalDateTime.now();
        this.puntosAcumulados=0;
        this.contadorComentarios=0;
        this.contadorRecompensas=0;
        this.contadorRecompensasObtenidas=0;
        this.contadorLogros=0;
    }
    /**
     * Constructor con parámetros
     */
    public Jugador(int idJugador, String nombre,String apellido,String conocimientoDeJuego, LocalDateTime fechaDeRegistro, Genero genero){
        // Validar el ID del jugador
        if (idJugador <= 0) {
            throw new IllegalArgumentException("El ID del jugador debe ser un número positivo.");
        }

        // Validación del nombre
        if (nombre == null || !nombre.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras");
        }
        if (nombre.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres");
        }

        //Validacion de apellido
        if (apellido == null || !apellido.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("El apellido solo puede contener letras");
        }

        //Validacion de conocimiento de juego
        if (conocimientoDeJuego == null || !conocimientoDeJuego.matches("(?i)(principiante|intermedio|avanzado)")) {
            throw new IllegalArgumentException("El nivel de conocimiento debe ser 'principiante', 'intermedio' o 'avanzado'");
        }

        // Validación del género
        if (genero == null) {
            throw new IllegalArgumentException("El género es obligatorio.");
        }

        this.idJugador = idJugador;
        this.nombre = nombre;
        this.apellido = apellido;
        this.conocimientoDeJuego = conocimientoDeJuego;
        this.fechaDeRegistro = fechaDeRegistro;
        this.genero = genero;
        this.recompensas = new SolicitudDeRecompensa[MAX_RECOMPENSAS];
        this.comentarios = new Comentario[MAX_COMENTARIOS];
        this.recompensas=new SolicitudDeRecompensa[MAX_RECOMPENSAS];
        this.recompensasObtenidas=new Recompensa[MAX_RECOMPENSAS_OBTENIDAS];
        this.logros=new Logro[MAX_LOGROS];
        this.puntosAcumulados=0;
        this.contadorComentarios = 0;
        this.contadorRecompensas = 0;
        this.contadorRecompensasObtenidas=0;
        this.contadorLogros=0;
    }
    public Jugador() {
        this(0, "", "", "", LocalDateTime.now());
    }
    /**
     * Obtiene el Id del jugador
     * @return el identificador unico del jugador
     */

    public int getIdJugador(){
        return idJugador;
    }
    /**
     * Establece el Id del jugador
     * @param idJugador
     */

    public void setIdJugador(int idJugador){
        this.idJugador = idJugador;
    }

    /**
     * Obtiene el nombre del jugador
     * @return El nombre actual del jugador
     */
    public String getNombre(){
        return nombre;
    }

    /**
     * Establece el nombre del jugador
     * @param nombre
     */
    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    /**
     * Obtiene el apellido del juagro
     * @return El apellido actual del jugador
     */
    public String getApellido(){
        return apellido;
    }

    /**
     * Establece el apellido del jugador
     * @param apellido
     */
    public void setApellido(String apellido){
        this.apellido = apellido;
    }

    /**
     * Obtiene el nivel de conocimiento del juego.
     * @return El nivel actual de conocimiento
     */
    public String getConocimientoDeJuego(){
        return conocimientoDeJuego;
    }

    /**
     * Establece el nivel de conocimiento del juego
     * @param conocimientoDeJuego
     */
    public void setConocimientoDeJuego(String conocimientoDeJuego){
        this.conocimientoDeJuego = conocimientoDeJuego;
    }

    /**
     * Obtiene la fecha de registro del jugador
     * @return la fecha y hora en que se registro el jugador
     */
    public LocalDateTime getFechaDeRegistro(){
        return fechaDeRegistro;
    }

    /**
     * Actualiza la fecha de registro con la fecha y hora actuales
     */
    public void setFechaDeRegistro(){
        this.fechaDeRegistro = LocalDateTime.now();
    }

    public int getPuntosAcumulados() { return puntosAcumulados; }
    public void setPuntosAcumulados(int puntosAcumulados) {
        this.puntosAcumulados = Math.max(0, puntosAcumulados);
    }
    /**
     * Obtiene copia de los comentarios activos
     */
    public Comentario[] getComentarios(){
        Comentario[] resultado=new Comentario[contadorComentarios];
        System.arraycopy(comentarios,0,resultado,0,contadorComentarios);
        return resultado;
    }
    /**
     * Obtiene copia de las recompensas activas
     */
    public SolicitudDeRecompensa[] getRecompensas(){
        SolicitudDeRecompensa[] resultado = new SolicitudDeRecompensa[contadorRecompensas];
        System.arraycopy(recompensas,0,resultado,0,contadorRecompensas);
        return resultado;
    }
    /**
     * Valida si un objeto ya existe en las asociaciones
     */
    public boolean validarDuplicado(Object obj){
        if (obj == null) return false;

        if (obj instanceof Comentario) {
            Comentario comentario = (Comentario) obj;
            for (int i = 0; i < contadorComentarios; i++) {
                if (comentarios[i] != null && comentarios[i].equals(comentario)) {
                    return true;
                }
            }
        } else if (obj instanceof SolicitudDeRecompensa) {
            SolicitudDeRecompensa recompensa = (SolicitudDeRecompensa) obj;
            for (int i = 0; i < contadorRecompensas; i++) {
                if (recompensas[i] != null && recompensas[i].equals(recompensa)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Calcula el total de puntos acumulados por todas las recompensas
     * @return La suma total de puntos de todas las recompensas
     */
    public int calcularTotalPuntos() {
        int total = 0;
        int contador = 0;
        for (Recompensa r : this.recompensasObtenidas) {
            if (contador >= this.contadorRecompensasObtenidas) break;
            if (r != null) {
                total += r.getPuntos();
            }
            contador++;
        }
        contador = 0;
        for (Logro l : this.logros) {
            if (contador >= this.contadorLogros) break;
            if (l != null && l.getCompletado()) {
                total += l.getPuntos();
            }
            contador++;
        }
        this.puntosAcumulados = total;
        return total;
    }
    /**
     * Registra una recompensa obtenida por el jugador
     * @param recompensa la recompensa a registrar
     */
    public void registrarRecompensa(Recompensa recompensa) {
        if (recompensa != null && this.contadorRecompensasObtenidas < this.recompensasObtenidas.length) {
            // Verificar si la recompensa ya existe
            boolean existe = false;
            for (int i = 0; i < this.contadorRecompensasObtenidas; i++) {
                if (this.recompensasObtenidas[i] != null && this.recompensasObtenidas[i].equals(recompensa)) {
                    existe = true;
                    break;
                }
            }

            if (!existe) {
                this.recompensasObtenidas[this.contadorRecompensasObtenidas] = recompensa;
                this.contadorRecompensasObtenidas++;
                this.calcularTotalPuntos(); // Actualizar puntos automáticamente
            }
        }
    }
    /**
     * Obtiene una copia de las recompensas obtenidas
     * @return array con las recompensas obtenidas
     */
    public Recompensa[] getRecompensasObtenidas() {
        Recompensa[] resultado = new Recompensa[this.contadorRecompensasObtenidas];
        System.arraycopy(this.recompensasObtenidas, 0, resultado, 0, this.contadorRecompensasObtenidas);
        return resultado;
    }

    /**
     * Registra un logro para el jugador
     * @param logro el logro a registrar
     */
    public void registrarLogro(Logro logro) {
        if (logro != null && this.contadorLogros < this.logros.length) {
            // Verificar si el logro ya existe
            boolean existe = false;
            for (int i = 0; i < this.contadorLogros; i++) {
                if (this.logros[i] != null && this.logros[i].equals(logro)) {
                    existe = true;
                    break;
                }
            }

            if (!existe) {
                this.logros[this.contadorLogros] = logro;
                this.contadorLogros++;
            }
        }
    }
    /**
     * Obtiene una copia de los logros del jugador
     * @return array con los logros
     */
    public Logro[] getLogros() {
        Logro[] resultado = new Logro[this.contadorLogros];
        System.arraycopy(this.logros, 0, resultado, 0, this.contadorLogros);
        return resultado;
    }

    /**
     * Completa un logro específico por nombre
     * @param nombreLogro nombre del logro a completar
     * @return true si se completó exitosamente, false en caso contrario
     */
    public boolean completarLogro(String nombreLogro) {
        if (nombreLogro == null || nombreLogro.trim().isEmpty()) {
            return false;
        }

        for (int i = 0; i < this.contadorLogros; i++) {
            Logro logro = this.logros[i];
            if (logro != null && logro.getNombre().equalsIgnoreCase(nombreLogro.trim()) && !logro.getCompletado()) {
                logro.completarLogro(logro.getNombre());
                this.calcularTotalPuntos();
                return true;
            }
        }
        return false;
    }

    /**
     * Obtiene la cantidad de logros completados
     * @return número de logros completados
     */
    public int getLogrosCompletados() {
        int completados = 0;
        for (int i = 0; i < this.contadorLogros; i++) {
            if (this.logros[i] != null && this.logros[i].getCompletado()) {
                completados++;
            }
        }
        return completados;
    }
    /**
     * Obtiene solo las recompensas aprobadas
     */
    public SolicitudDeRecompensa[] obtenerRecompensasAprobadas() {
        int aprobadas = 0;
        for (int i = 0; i < contadorRecompensas; i++) {
            if (recompensas[i] != null && recompensas[i].estaAprobada()) {
                aprobadas++;
            }
        }

        SolicitudDeRecompensa[] resultado = new SolicitudDeRecompensa[aprobadas];
        int index = 0;

        for (int i = 0; i < contadorRecompensas; i++) {
            if (recompensas[i] != null && recompensas[i].estaAprobada()) {
                resultado[index++] = recompensas[i];
            }
        }

        return resultado;
    }

    /**
     * Muestra todas las recompensas del jugador
     * @return String con la información de todas las recompensas
     */
    public String mostrarRecompensas() {
        StringBuilder sb = new StringBuilder();

        // Verificar que el nombre no sea null
        String nombreCompleto = (this.nombre != null ? this.nombre : "Sin nombre") +
                " " + (this.apellido != null ? this.apellido : "Sin apellido");

        sb.append("=== RECOMPENSAS DE ").append(nombreCompleto).append(" ===\n\n");

        // SECCIÓN 1: SOLICITUDES DE RECOMPENSA
        sb.append(" SOLICITUDES DE RECOMPENSA (").append(this.contadorRecompensas).append("):\n");
        if (this.contadorRecompensas == 0) {
            sb.append(" No tiene solicitudes de recompensa.\n");
        } else {
            for (int i = 0; i < this.contadorRecompensas; i++) {
                if (this.recompensas[i] != null) {
                    SolicitudDeRecompensa solicitud = this.recompensas[i];
                    sb.append((i + 1)).append(". ");

                    if (solicitud.estaAprobada()) {
                        sb.append(" APROBADA - ");
                    } else {
                        sb.append(" PENDIENTE - ");
                    }

                    sb.append(solicitud.toString()).append("\n");
                }
            }
        }

        sb.append("\n");

        // SECCIÓN 2: RECOMPENSAS OBTENIDAS
        sb.append(" RECOMPENSAS OBTENIDAS (").append(this.contadorRecompensasObtenidas).append("):\n");
        if (this.contadorRecompensasObtenidas == 0) {
            sb.append(" No tiene recompensas obtenidas.\n");
        } else {
            int puntosDeRecompensas = 0;
            for (int i = 0; i < this.contadorRecompensasObtenidas; i++) {
                if (this.recompensasObtenidas[i] != null) {
                    Recompensa recompensa = this.recompensasObtenidas[i];
                    sb.append((i + 1)).append(". 🎁 ")
                            .append(recompensa.getNombre())
                            .append(" - ").append(recompensa.getPuntos()).append(" puntos\n");

                    if (recompensa.getDescripcion() != null && !recompensa.getDescripcion().trim().isEmpty()) {
                        sb.append("   📝 ").append(recompensa.getDescripcion()).append("\n");
                    }

                    puntosDeRecompensas += recompensa.getPuntos();
                }
            }
            sb.append("\n💎 Total puntos de recompensas: ").append(puntosDeRecompensas).append("\n");
        }

        return sb.toString();
    }

    /**
     * Muestra solo las recompensas aprobadas del jugador
     * @return String con la información de las recompensas aprobadas
     */

    public String mostrarRecompensasAprobadas() {
        SolicitudDeRecompensa[] aprobadas = this.obtenerRecompensasAprobadas();

        if (aprobadas.length == 0) {
            return "El jugador " + this.nombre + " " + this.apellido + " no tiene recompensas aprobadas.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Recompensas aprobadas de ").append(this.nombre).append(" ").append(this.apellido).append(":\n");

        for (SolicitudDeRecompensa recompensa : aprobadas) {
            sb.append("- ").append(recompensa.toString()).append("\n");
        }

        return sb.toString();
    }

    /**
     * Muestra los logros alcanzados por el jugador
     * @return String con información de los logros
     */
    public String mostrarLogros() {
        StringBuilder sb = new StringBuilder();

        // Verificar que el nombre no sea null
        String nombreCompleto = (this.nombre != null ? this.nombre : "Sin nombre") +
                " " + (this.apellido != null ? this.apellido : "Sin apellido");

        sb.append("=== LOGROS DE ").append(nombreCompleto).append(" ===\n");
        sb.append("Puntos totales acumulados: ").append(this.puntosAcumulados).append("\n");
        sb.append("Total de logros registrados: ").append(this.contadorLogros).append("\n");
        sb.append("Logros completados: ").append(this.getLogrosCompletados()).append("\n");
        sb.append("Recompensas obtenidas: ").append(this.contadorRecompensasObtenidas).append("\n");
        sb.append("Comentarios realizados: ").append(this.contadorComentarios).append("\n");
        sb.append("Nivel de conocimiento: ").append(this.conocimientoDeJuego != null ? this.conocimientoDeJuego : "No definido").append("\n\n");

        // Mostrar cada logro individual
        if (this.contadorLogros == 0) {
            sb.append("❌ No tiene logros registrados.\n");
        } else {
            sb.append("📋 DETALLE DE LOGROS:\n");
            for (int i = 0; i < this.contadorLogros; i++) {
                if (this.logros[i] != null) {
                    Logro logro = this.logros[i];
                    sb.append((i + 1)).append(". ");

                    if (logro.getCompletado()) {
                        sb.append("✅ ");
                    } else {
                        sb.append("⏳ ");
                    }

                    sb.append(logro.getNombre())
                            .append(" - ").append(logro.getPuntos()).append(" puntos")
                            .append(" (").append(logro.getCompletado() ? "COMPLETADO" : "PENDIENTE").append(")\n");

                    if (logro.getDescripcion() != null && !logro.getDescripcion().trim().isEmpty()) {
                        sb.append("   📝 ").append(logro.getDescripcion()).append("\n");
                    }
                    sb.append("\n");
                }
            }
        }

        return sb.toString();
    }

    public String seleccionarModoDeJuego(){
        String modoSeleccionado;
        switch (conocimientoDeJuego.toLowerCase()) {
            case "principiante":
            case "basico":
                modoSeleccionado = "Modo Fácil";
                break;
            case "intermedio":
                modoSeleccionado = "Modo Normal";
                break;
            case "avanzado":
            case "experto":
                modoSeleccionado = "Modo Difícil";
                break;
            default:
                modoSeleccionado = "Modo Normal"; // Por defecto
                break;
        }

        System.out.println("Jugador " + nombre + " ha seleccionado: " + modoSeleccionado);
        return modoSeleccionado;
    }
    /**
     * Sobrecarga: Agregar comentario por texto
     */
    public boolean agregarComentario(String texto){
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El texto del comentario no puede estar vacío");
        }
        if (contadorComentarios < comentarios.length) {
            Comentario nuevoComentario = new Comentario();

            if (!validarDuplicado(nuevoComentario)) {
                comentarios[contadorComentarios] = nuevoComentario;
                contadorComentarios++;
                return true;
            }
        }
        return false;
    }
    /**
     * Sobrecarga: Agregar comentario por objeto
     */
    public boolean agregarComentario(Comentario comentario) {
        if (comentario == null) {
            throw new IllegalArgumentException("El comentario no puede ser null");
        }

        if (contadorComentarios < comentarios.length) {
            if (!validarDuplicado(comentario)) {
                comentarios[contadorComentarios] = comentario;
                contadorComentarios++;
                return true;
            }
        }
        return false;
    }
    /**
     * Agrega una solicitud de recompensa por parámetros
     */
    public boolean agregarSolicitudRecompensa(EstadoDeSolicitud tipoRecompensa, Recompensa puntosRequeridos){
        if (tipoRecompensa == null) {
            throw new IllegalArgumentException("El tipo de recompensa no puede estar vacío");
        }
        if (contadorRecompensas < recompensas.length) {
            SolicitudDeRecompensa nuevaRecompensa = new SolicitudDeRecompensa();

            if (!validarDuplicado(nuevaRecompensa)) {
                recompensas[contadorRecompensas] = nuevaRecompensa;
                contadorRecompensas++;
                return true;
            }
        }
        return false;
    }
    /**
     * Agrega una solicitud de recompensa por objeto
     */
    public boolean agregarSolicitudRecompensa(SolicitudDeRecompensa recompensa) {
        if (recompensa == null) {
            throw new IllegalArgumentException("La recompensa no puede ser null");
        }

        if (contadorRecompensas < recompensas.length) {
            if (!validarDuplicado(recompensa)) {
                recompensas[contadorRecompensas] = recompensa;
                contadorRecompensas++;
                return true;
            }
        }
        return false;
    }

    public boolean aprobarRecompensa(int idRecompensa){
        for (SolicitudDeRecompensa recompensa : recompensas) {
            if (recompensa != null && recompensa.getId() == idRecompensa) {
                recompensa.estaAprobada();
                return true;
            }
        }
        return false;
    }

    public boolean eliminarComentario(int indice) {
        if (indice >= 0 && indice < contadorComentarios) {
            // Mover elementos hacia la izquierda
            for (int i = indice; i < contadorComentarios - 1; i++) {
                comentarios[i] = comentarios[i + 1];
            }
            contadorComentarios--;
            comentarios[contadorComentarios] = null; // limpiar referencia
            return true;
        }
        return false;
    }

    public boolean eliminarSolicitudRecompensa(int idRecompensa) {
        for (int i = 0; i < contadorRecompensas; i++) {
            if (recompensas[i] != null && recompensas[i].getId() == idRecompensa) {
                for (int j = i; j < contadorRecompensas - 1; j++) {
                    recompensas[j] = recompensas[j + 1];
                }
                contadorRecompensas--;
                recompensas[contadorRecompensas] = null;
                return true;
            }
        }
        return false;
    }

    public boolean actualizarComentario(int indice, String nuevoTexto) {
        if (indice >= 0 && indice < contadorComentarios) {
            comentarios[indice].setContenido(nuevoTexto);
            comentarios[indice].getFecha(); // actualizar fecha
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "*******  Jugador *******" +
                " idJugador: " + idJugador + ", nombre: " + nombre + ", apellido: " + apellido + ", genero: " + genero +
                " conocimientoDeJuego: " + conocimientoDeJuego + ", fechaDeRegistro: " + fechaDeRegistro +
                "\nrecompensas: " + Arrays.toString(recompensas) +
                "\ncomentarios: " + Arrays.toString(comentarios) +
                "\nrecompensasObtenidas: " + Arrays.toString(recompensasObtenidas) +
                ", logros=" + Arrays.toString(logros) +
                ", puntosAcumulados: " + puntosAcumulados +
                ", contadorRecompensas: " + contadorRecompensas +
                ", contadorRecompensasObtenidas: " + contadorRecompensasObtenidas ;
    }

    public boolean equals(Object obj){
        if (this==obj)return true;
        if (obj==null) return false;
        if(!(obj instanceof Jugador)) return false;
        Jugador otroJugador=(Jugador)obj;
        return  this.idJugador==otroJugador.idJugador &&
                Objects.equals(this.nombre, otroJugador.nombre) &&
                Objects.equals(this.apellido, otroJugador.apellido);
    }
    /**
     * Metodo hashCode para mantener consistencia con equals
     */
    public int hashCode(){
        return Objects.hash(this.idJugador, this.nombre, this.apellido);
    }
}

