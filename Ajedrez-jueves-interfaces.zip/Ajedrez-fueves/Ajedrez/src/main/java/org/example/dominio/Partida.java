package org.example.dominio;


import java.time.LocalDateTime;
import java.util.Objects;

/**
 *Representacion de una partida de juego que gestiona un conjunto de
 * jugadores Permite registrar, buscar, editar y eliminar jugadores
 * asi como gestionar el arreglo dinamico de jugadores participantes
 */
public class Partida {
    private int numJugadores;
    public Jugador[] jugadores;
    private int puntajeJugador1;
    private int puntajeJugador2;
    private LocalDateTime fecha;
    private String observaciones;
    private EstadoEnfrentamiento estado;
    public Partida[] partidas;
    private int numPartidas;
    private Contrincante contrincante;
    private Jugador ganador;
    private Jugador jugador1;
    private Jugador jugador2;
    public final int IDPARTIDA;
    public static int contador;

    static {contador = 0;}
    /**
     * Constructor que inicializa una partida con capacidad para 2 jugadores
     * inicialmente El arreglo se expandira automaticamente cuando sea
     * necesario
     */
    public Partida(){
        this(01,2,LocalDateTime.now(), "sin observaciones", Contrincante.SINCONTRINCANTE,EstadoEnfrentamiento.SIN_JUGAR);
    }
    public Partida(int punJ1, int punJ2, LocalDateTime fecha, String obs, Contrincante contrincante,EstadoEnfrentamiento estado) {
        partidas = new Partida[3];
        this.puntajeJugador1 = punJ1;
        this.puntajeJugador2 = punJ2;
        this.fecha = LocalDateTime.now();
        this.observaciones = obs;
        this.estado = EstadoEnfrentamiento.SIN_JUGAR;
        this.contrincante = Contrincante.SINCONTRINCANTE;
        IDPARTIDA = contador++;
    }

    public Partida(int nuevoPuntajeJ1, int nuevoPuntajeJ2,
                   LocalDateTime nuevaFecha, String nuevasObservaciones, EstadoEnfrentamiento nuevoEstado, Contrincante nuevoContrincante) {
        this.puntajeJugador1 = nuevoPuntajeJ1;
        this.puntajeJugador2 = nuevoPuntajeJ2;
        this.fecha = nuevaFecha;
        this.observaciones = nuevasObservaciones;
        this.estado = nuevoEstado;
        this.contrincante = nuevoContrincante;
        IDPARTIDA = contador++;
    }

    //Metodos get
    public Jugador getJugador(int indice){
        if (indice >= 0 && indice < numJugadores) {
            return jugadores[indice];
        } else {
            return null;
        }
    }
    public int getNumJugadores() {return numJugadores;}
    public String getObservaciones() {return observaciones;}
    public int getIdPartida() {return IDPARTIDA;}
    public int getPuntajeJugador1() {return puntajeJugador1;}
    public Jugador getJugador2() {return jugador2;}
    public LocalDateTime getFecha() {return fecha;}
    public int getNumPartidas() {return numPartidas;}
    public Jugador getGanador() {return ganador;}
    public int getPuntajeJugador2() {return puntajeJugador2;}
    public Partida[] getPartidas() {return partidas;}
    public EstadoEnfrentamiento getEstado() {return estado;}
    public Jugador getJugador1() {return jugador1;}
    public Jugador[] getJugadores() {return jugadores;}
    public Contrincante getContrincante() {return contrincante;}

    //Metodos set
    public void setJugador(int indice, Jugador jugador){jugadores[indice]=jugador;}
    public void setNumJugadores(int numJugadores) {this.numJugadores = numJugadores;}
    public void setObservaciones(String observaciones) {this.observaciones = observaciones != null ? observaciones : "";}
    public void setPuntajeJugador1(int puntajeJugador1) {this.puntajeJugador1 = puntajeJugador1;}
    public void setJugador2(Jugador jugador2) {this.jugador2 = jugador2;}
    public void setFecha(LocalDateTime fecha) {this.fecha = fecha;}
    public void setNumPartidas(int numPartidas) {this.numPartidas = numPartidas;}
    public void setGanador(Jugador ganador) {this.ganador = ganador;}
    public void setPuntajeJugador2(int puntajeJugador2) {this.puntajeJugador2 = puntajeJugador2;}
    public void setPartidas(Partida[] partidas) {this.partidas = partidas;}
    public void setEstado(EstadoEnfrentamiento estado) {this.estado = estado;}
    public void setJugador1(Jugador jugador1) {this.jugador1 = jugador1;}
    public void setJugadores(Jugador[] jugadores) {this.jugadores = jugadores;}
    public void setContrincante(Contrincante contrincante) {this.contrincante = contrincante;}

    //Metodos CRUD
    public String crearPartidaMaquina() {
        return "Partida contra la maquina";
    }
    public String crearPartidaMultijugador() {

        return "Partida multijugadore creada con exito";
    }
    public String registrarPartida(int punJ1, int punJ2, String obs,
                                   LocalDateTime fecha, EstadoEnfrentamiento estado, Contrincante contrincante) {
        // Registrar la partida en el arreglo
        if (numPartidas==partidas.length){
            Partida[] partiaux = partidas;
            partidas = new Partida[numPartidas + 1];
            System.arraycopy(partiaux,0,partidas,0,numPartidas);
        }

        partidas[numPartidas] = new Partida(punJ1, punJ2, fecha, obs, contrincante, estado);
        numPartidas++;
        return "Partida registrada con éxito: " ;
    }
    public String consultarPartida() {
        String resultado = "";
        for (int i = 0; i < partidas.length; i++) {
            if (partidas[i] != null) {
                resultado += "\n" + partidas[i] + "\n\n";
            }
        }
        if (resultado.equals("")) {
            return "No hay partidas registradas.";
        }
        return resultado;
    }
    public int buscarPartidaPorId(int id) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                return i;
            }
        }
        return -1;
    }
    public void editarPartida(int indice, int IDPARTIDA, int puntajeJugador1, int puntajeJugador2, String observaciones, LocalDateTime fecha) {
        if (indice < 0 || indice >= numPartidas) {
            System.out.println("Índice de jugador no válido.");
            return;
        }

        try {
            //partidas[indice] = new Partida(IDPARTIDA, puntajeJugador1, puntajeJugador2, fecha, observaciones);
            System.out.println("Partida modificada correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al modificar la partida: " + e.getMessage());
        }
    }
    public boolean eliminarPartida(int id) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numPartidas - 1; j++) {
                    partidas[j] = partidas[j + 1];
                }
                partidas[numPartidas - 1] = null;
                numPartidas--;
                return true;
            }
        }
        return false;
    }

    //Sobrecarga de metodos CRUD
    public String crearPartidaMaquina(String soPartida) {
        return "Partida contra la maquina";
    }
    public String crearPartidaMultijugador(String soPartida) {
        if (jugadores.length < 2){
            return "Es necesario que participen 2 jugadores.";
        }
        return soPartida;
    }
    public String registrarPartida(Partida partida) {
        if (partida == null) {
            return "Error: La partida no puede ser null";
        }

        if (numPartidas == partidas.length) {
            Partida[] partiaux = partidas;
            partidas = new Partida[numPartidas + 1];
            System.arraycopy(partiaux, 0, partidas, 0, numPartidas);
        }

        partidas[numPartidas] = partida;
        numPartidas++;
        return "Partida registrada desde objeto: ID " + partida.getIdPartida();
    }
    public String consultarPartida(Partida partida) {
        String resultado = "";
        for (int i = 0; i < partidas.length; i++) {
            if (partidas[i] != null) {
                resultado += "\n" + partidas[i] + "\n\n";
            }
        }
        if (resultado.equals("")) {
            return "No hay partidas registradas.";
        }
        return resultado;
    }
    public int buscarPartidaPorId(int id, Partida partida) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                return i;
            }
        }
        return -1;
    }
    public boolean eliminarPartida(int id, Partida partida) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numPartidas - 1; j++) {
                    partidas[j] = partidas[j + 1];
                }
                partidas[numPartidas - 1] = null;
                numPartidas--;
                return true;
            }
        }
        return false;
    }

    //Metodos
    public String asignarEmpate() {
        this.estado = EstadoEnfrentamiento.EMPATE;
        //this.ganador = null;
        this.puntajeJugador1 = 0;
        this.puntajeJugador2 = 0;
        return "Resultado asignado: Empate";
    }
    public String asignarResultadoConPuntaje(int puntajeJ1, int puntajeJ2) {
        this.puntajeJugador1 = puntajeJ1;
        this.puntajeJugador2 = puntajeJ2;

        if (puntajeJ1 > puntajeJ2) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR1;
            this.ganador = jugador1;
        } else if (puntajeJ2 > puntajeJ1) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR2;
            this.ganador = jugador2;
        } else {
            this.estado = EstadoEnfrentamiento.EMPATE;
            this.ganador = null;
        }

        return "Resultado asignado con puntajes: " + puntajeJ1 + " - " + puntajeJ2;
    }
    public String asignarGanador(Jugador nombreGanador) {
        String nombreJ1 = jugador1.getNombre() + " " + jugador1.getApellido();
        String nombreJ2 = jugador2.getNombre() + " " + jugador2.getApellido();

        if (nombreGanador.equals(nombreJ1)) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR1;
            this.puntajeJugador1 = 1;
            this.puntajeJugador2 = 0;
            return "Resultado asignado: Ganador - " + nombreJ1;
        } else if (nombreGanador.equals(nombreJ2)) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR2;
            this.puntajeJugador1 = 0;
            this.puntajeJugador2 = 1;
            return "Resultado asignado: Ganador - " + nombreJ2;
        } else {
            throw new IllegalArgumentException("El jugador ganador debe ser uno de los participantes del enfrentamiento.");
        }
    }
    public String asignarResultados(String resultado) {
        if (resultado == null) {
            return "Resultado no válido.";
        }

        String nombreJ1 = jugador1.getNombre() + " " + jugador1.getApellido();
        String nombreJ2 = jugador2.getNombre() + " " + jugador2.getApellido();

        if (resultado.equals(nombreJ1)) {
            asignarGanador(jugador1);
        } else if (resultado.equals(nombreJ2)) {
            asignarGanador(jugador2);
        } else if (resultado.equalsIgnoreCase("Empate")) {
            asignarEmpate();
        } else {
            return "Resultado no válido.";
        }
        return nombreJ1;
    }
    private String validarDuplicadoJugador(Jugador jugador) {
        if (jugadores == null || numJugadores == 0) {
            return "No hay jugadores registrados, no es duplicado";
        }

        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i] != null && jugadores[i].equals(jugador)) {
                return "Jugador duplicado encontrado: " +
                        jugador.getNombre() + " " + jugador.getApellido();
            }
        }

        return "Jugador no duplicado: " + jugador.getNombre() + " " + jugador.getApellido();

    }
    @Override
    public String toString() {
        return "=== INFORMACIÓN DE LA PARTIDA ===" +
                "\nPartida id: " + IDPARTIDA +
                "\nContrincante: " + contrincante +
                "\nFecha: " + fecha +
                "\nPuntaje Jugador 1: " + puntajeJugador1 +
                "\nPuntaje Jugador 2: " + puntajeJugador2 +
                "\nObservaciones: " + observaciones +
                "\n================================";
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Partida)) {
            return false;
        }

        Partida partida = (Partida) obj;

        return Objects.equals(fecha, partida.fecha) &&
                estado == partida.estado &&
                Objects.equals(contrincante, partida.contrincante);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(fecha, estado, contrincante);
        result = 31 * result;
        return result;
    }
}
