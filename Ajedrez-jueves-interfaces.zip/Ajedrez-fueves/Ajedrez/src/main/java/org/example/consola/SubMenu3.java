package org.example.consola;

import org.example.dominio.Competencia;
import org.example.dominio.Genero;
import org.example.dominio.Jugador;
import org.example.dominio.Partida;
import org.example.util.Validador;

import java.time.LocalDateTime;
import java.util.Scanner;

/**
 * Clase que representa el submenú para la gestión de jugadores.
 * Permite registrar, modificar, consultar y eliminar jugadores dentro de una jugador.
 */
public class SubMenu3 {
    /**
     * Muestra el submenú de gestión de jugadores.
     * Permite al usuario interactuar con el sistema para realizar
     * operaciones CRUD (crear, leer, actualizar, eliminar) sobre jugadores.
     *
     */
    public static void subMenu3(String[] args){
        Competencia jugador = new Competencia();
        Partida jugador1 = new Partida();
        Genero genero = null;
        int op;
        boolean val1= true;
        Scanner leer = new Scanner(System.in);

        while (val1 == true) {
            System.out.println("");
            System.out.println("H2. Gestionar jugador");
            System.out.println("    1. Registrar jugador.\n" +
                    "    2. Modificar jugador.\n" +
                    "    3. Consultar jugador.\n" +
                    "    4. Eliminar jugador.\n" +
                    "    5. Salir.");
            System.out.println("Ingrese la opcion a la que desee acceder:");
            op = Validador.pedirNumero(leer);
            System.out.println("");
            switch (op) {
                case 1:
                    System.out.println("H2.1. Registrar jugador.");
                    //Scanner sc = new Scanner(System.in);
                    int id = -1;
                    System.out.print("Ingrese el ID del jugador: ");
                    id = Validador.pedirNumero(leer);
                    System.out.print("Ingrese el nombre del jugador: ");
                    String nom = Validador.pedirNombre(leer);
                    System.out.print("Ingrese el apellido del jugador: ");
                    String apel = Validador.pedirNombre(leer);
                    System.out.print("Ingrese el nivel de conocimiento del juego: (principiante, intermedio, avanzado)");
                    String nivel = Validador.pedirNivel(leer);
                    jugador.registrarJugador(id, nom, apel, nivel, LocalDateTime.now(), Validador.ejegirGenero());
                    if (jugador.validarDuplicado(jugador)) {  // Si tienes este método
                        System.out.println("ERROR: Ya existe un jugador con ID " + id + " o con nombre " + nom + " " + apel);
                        System.out.println("Por favor, verifique los datos e intente nuevamente.");
                    } else {
                        System.out.println("Jugador registrado exitosamente.");
                    }
                    break;

                case 2:
                    System.out.println("H2.2. Modificar jugador.");
                    System.out.println("Jugadores actuales: ");
                    for (int i = 0; i < jugador.getNumJugadores(); i++) {
                        System.out.println("[" + i + "] " + jugador.getJugadores(i));
                    }

                    System.out.print("Ingrese el id del jugador a modificar: ");
                    int idBuscado = Validador.pedirNumero(leer);

                    int indice = jugador.buscarIndicePorId(idBuscado);

                    if (indice == -1) {
                        System.out.println("Jugador con ID " + idBuscado + " no encontrado.");
                    } else {
                        System.out.println("Jugador anterior: " + jugador.jugadores[indice]);

                        // Pedir datos nuevos (por ejemplo)
                        System.out.print("Nuevo ID: ");
                        int nuevoId = leer.nextInt();

                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = leer.next();

                        System.out.print("Nuevo apellido: ");
                        String nuevoApellido = leer.next();

                        System.out.print("Nuevo nivel de conocimiento (principiante, intermedio, avanzado): ");
                        String nuevoNivel = leer.next();

                        jugador.modificarJugador(indice, nuevoId, nuevoNombre, nuevoApellido, nuevoNivel, LocalDateTime.now(),Validador.ejegirGenero());
                    }
                    break;
                case 3:
                    System.out.println("H2.1. Consultar jugador.");
                    System.out.print("Ingrese el ID del jugador a consultar: ");

                    int idConsulta = Validador.pedirNumero(leer);
                    leer.nextLine(); // limpiar salto

                    Jugador encontrado = jugador.buscarJugador(idConsulta);

                    if (encontrado != null) {
                        System.out.println("Jugador encontrado:");
                        System.out.println(encontrado);
                    } else {
                        System.out.println("No se encontró ningún jugador con ese ID.");
                    }
                    break;
                case 4:
                    System.out.println("H2.1. Eliminar jugador.");
                    System.out.print("Ingrese el ID del jugador que desea eliminar: ");
                    int idEliminar = Validador.pedirNumero(leer);
                    leer.nextLine();

                    boolean eliminado = jugador.borrarJugador(idEliminar);

                    if (eliminado) {
                        System.out.println("Jugador eliminado correctamente.");
                    } else {
                        System.out.println("No se encontró ningún jugador con ese ID.");
                    }
                    break;
                case 5:
                    val1 = false;
                    break;
                default:
                    System.out.println("Este valor no esta disponible.");
            }
        }
    }
}
