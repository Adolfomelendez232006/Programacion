package org.example.util;

import org.example.dominio.Genero;

import java.util.Scanner;

public class Validador {

    public static String pedirNombre(Scanner scanner) {
        while (true) {
            //System.out.print("Ingresa tu nombre: ");
            String nombre = scanner.nextLine();
            if (nombre.matches("[a-zA-Z]+")) {
                return nombre;
            } else {
                System.out.println("El nombre solo debe contener letras. Intenta nuevamente.");
            }
        }
    }

    public static int pedirNumero(Scanner leer) {
        int numero;
        while (true) {
            try {
                String entrada = leer.nextLine();
                numero = Integer.parseInt(entrada);
                if (numero > 0) {
                    return numero;
                } else {
                    System.out.println("El número debe ser positivo. Intenta nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("El número solo debe contener dígitos. Intenta nuevamente.");
            }
        }
    }
    public static String pedirNivel(Scanner scanner) {
        while (true) {
            String entrada = scanner.nextLine();
            if (entrada.matches("(?i)(principiante|intermedio|avanzado)")) {
                return entrada; // Devuelve la entrada si es válida
            } else {
                System.out.print("Nivel inválido. Ingresa 'principiante', 'intermedio' o 'avanzado': ");
            }
        }
    }

    public static Genero ejegirGenero(){
        Scanner leer = new Scanner(System.in);
        System.out.println("Seleccione el género del jugador:");
        System.out.println("1. Masculino");
        System.out.println("2. Femenino");

        int opcionGenero = Validador.pedirNumero(leer);

        Genero genero;
        switch (opcionGenero) {
            case 1:
                genero = Genero.MASCULINO;
                break;
            case 2:
                genero = Genero.FEMENINO;
                break;
            default:
                throw new IllegalArgumentException("Opción de género inválida.");
        }
        return genero;
    }
    public static boolean validarSoloLetrasYEspacios(String texto) {
        // Verificar que el texto no sea nulo o vacío
        if (texto == null || texto.trim().isEmpty()) {
            return false;
        }

        // Verificar que no inicie o termine con espacios
        if (texto.startsWith(" ") || texto.endsWith(" ")) {
            return false;
        }

        // Verificar que no tenga espacios dobles
        if (texto.contains("  ")) {
            return false;
        }

        // Verificar cada carácter
        for (char c : texto.toCharArray()) {
            if (!Character.isLetter(c) && c != ' ') {
                return false;
            }
        }

        return true;
    }
    public static String solicitarTextoValido(Scanner leer) {
        String texto;
        do {

            texto = leer.nextLine();

            if (!validarSoloLetrasYEspacios(texto)) {
                return "No es valido";
            }

        } while (!validarSoloLetrasYEspacios(texto));

        return texto;
    }

}
