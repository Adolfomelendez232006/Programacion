package org.example.Datos;

import org.example.dominio.EstadoDeSolicitud;
import org.example.dominio.Logro;
import org.example.dominio.Recompensa;
import org.example.dominio.SolicitudDeRecompensa;

public interface JugadorDAO {

    //Interfaz para la gestion de los puntos
    int calcularTotalPuntos();

    //Para gestionar los comentarios
    boolean agregarComentario(String texto);
    boolean eliminarComentario(int indice);
    boolean actualizarComentario(int indice, String nuevoTexto);

    //Para la gestion de las recompensas
    boolean agregarSolicitudRecompensa(EstadoDeSolicitud tipoRecompensa, Recompensa puntosRequeridos);
    boolean eliminarSolicitudRecompensa(int idRecompensa);
    boolean aprobarRecompensa(int idRecompensa);
    SolicitudDeRecompensa[] obtenerRecompensasAprobadas();
    String mostrarRecompensasAprobadas();
    String mostrarRecompensas();

    //para la gestion de los logros
    void registrarLogro(Logro logro);
    boolean completarLogro(String nombreLogro);
    String mostrarLogros();

}
