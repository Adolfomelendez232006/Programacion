package org.example.dominio;

import java.util.Objects;
import java.util.Scanner;

/**
 * Proporciona un tutorial sobre ajedrez, incluyendo información
 * sobre piezas, fundamentos básicos, estrategias intermedias y
 * técnicas avanzadas.
 * <p>El tutorial está organizado en cuatro secciones principales:
 * <ol>
 *     <li>Descripción de las piezas de ajedrez</li>
 *     <li>Fundamentos básicos del juego</li>
 *     <li>Consejos y estrategias de nivel intermedio</li>
 *     <li>Técnicas avanzadas y tácticas</li>
 * </ol>
 * </p>
 */
public class Tutorial {
    public String piezasDeAjedrez;
    public String fundamentos;
    public String intermedio;
    public String avanzado;

    // final
    public static final String VERSION = "1.0";
    public static final String AUTOR = "Administrador";

    // Constructor predeterminado que configura el tutorial
    public Tutorial() {
        establecerTutorial();
    }

    // Este método estático puede mostrarse sin crear un objeto Tutorial
    public static void mostrarIntroduccion() {
        System.out.println("=== Tutorial de Ajedrez v" + VERSION + " ===");
        System.out.println("Creado por: " + AUTOR);
        System.out.println("¡Aprende desde lo básico hasta técnicas avanzadas!");
    }
        // Constructor predeterminado que configura el tutorial
        public void establecerTutorial () {
            this.piezasDeAjedrez = "Las piezas de ajedrez son: rey, dama, torre, alfil, caballo y peón.";
            this.fundamentos = "El objetivo del juego es dar jaque mate al rey del oponente.";
            this.intermedio = "Controla el centro, desarrolla las piezas y protege al rey (enroque).";
            this.avanzado = "Tácticas: clavadas, ataques dobles, sacrificios, y finales estratégicos.";
        }

        public String mostrarTutorial () {
            return "\n=== Tutorial de Ajedrez ===\n" +
                    "1. Piezas de Ajedrez: " + this.piezasDeAjedrez + "\n" +
                    "2. Fundamentos: " + this.fundamentos + "\n" +
                    "3. Nivel Intermedio: " + this.intermedio + "\n" +
                    "4. Nivel Avanzado: " + this.avanzado + "\n";
        }

        // Método principal para editar secciones
        public String editarTutorial (String seccion, String nuevoContenido){
            switch (seccion.toLowerCase()) {
                case "piezas":
                    this.piezasDeAjedrez = nuevoContenido;
                    return "Sección 'piezas' actualizada.";
                case "fundamentos":
                    this.fundamentos = nuevoContenido;
                    return "Sección 'fundamentos' actualizada.";
                case "intermedio":
                    this.intermedio = nuevoContenido;
                    return "Sección 'intermedio' actualizada.";
                case "avanzado":
                    this.avanzado = nuevoContenido;
                    return "Sección 'avanzado' actualizada.";
                default:
                    return "Sección no válida.";
            }
        }

        // Sobrecarga: permite editar todas las secciones a la vez
        public void editarTutorial (String piezas, String fundamentos, String intermedio, String avanzado){
            this.piezasDeAjedrez = piezas;
            this.fundamentos = fundamentos;
            this.intermedio = intermedio;
            this.avanzado = avanzado;
        }

        // Elimina todo el contenido
        public void eliminarTutorial () {
            this.piezasDeAjedrez = "";
            this.fundamentos = "";
            this.intermedio = "";
            this.avanzado = "";
        }

        // Sobrecarga: elimina solo una sección específica
        public void eliminarTutorial (String seccion){
            switch (seccion.toLowerCase()) {
                case "piezas":
                    this.piezasDeAjedrez = "";
                    break;
                case "fundamentos":
                    this.fundamentos = "";
                    break;
                case "intermedio":
                    this.intermedio = "";
                    break;
                case "avanzado":
                    this.avanzado = "";
                    break;
            }
        }

        // equals y hashCode
        @Override
        public boolean equals (Object obj){
            if (this == obj) return true;
            if (!(obj instanceof Tutorial)) return false;
            Tutorial t = (Tutorial) obj;
            return Objects.equals(this.piezasDeAjedrez, t.piezasDeAjedrez) &&
                    Objects.equals(this.fundamentos, t.fundamentos) &&
                    Objects.equals(this.intermedio, t.intermedio) &&
                    Objects.equals(this.avanzado, t.avanzado);
        }

        @Override
        public int hashCode () {
            return Objects.hash(this.piezasDeAjedrez, this.fundamentos, this.intermedio, this.avanzado);
        }
}
