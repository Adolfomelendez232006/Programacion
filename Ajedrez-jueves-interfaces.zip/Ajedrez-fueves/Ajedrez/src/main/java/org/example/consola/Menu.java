package org.example.consola;

import java.util.Scanner;
/**
 * Clase que muestra el menú principal del programa de ajedrez.
 * Desde aquí el usuario puede ir a otros menús para gestionar diferentes partes del sistema.
 */
public class Menu {
    /**
     * Metodo principal que se ejecuta al iniciar el programa.
     * Muestra un menú con opciones y llama a otros submenús según lo que el usuario elija.
     *
     */
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        int op;
        boolean val = true;

        do {
            System.out.println("");
            System.out.println("Menu de ajedrez");
            System.out.println("1. Gestionar competencia.\n" +
                    "2. Gestionar partida.\n" +
                    "3. Gestionar jugador.\n" +
                    "4. Gestionar recompensa.\n" +
                    "5. Salir");

            System.out.println("Ingrese la opcion a la que desee acceder:");
            op = leer.nextInt();
            System.out.println("");
            switch (op) {
                case 1:
                    //Menu para gestionar la competencia
                   SubMenu1.subMenu1(args);
                   break;
                case 2:
                    //Menu para gestionar la partida
                   SubMenu2.subMenu2(args);
                    break;
                case 3:
                    //Menu para gestionar al jugador
                    SubMenu3.subMenu3(args);
                    break;
                case 4:
                    //Menu para gestionar las recompensas
                    SubMenu4.subMenu4(args);
                    break;
                case 5:
                    System.out.println("Gracias por usar nuestro programa.");
                    val = false;
                    break;
                default:
                    System.out.println("Estos valores no son validos.");
            }
        } while (val == true);
    }
}
